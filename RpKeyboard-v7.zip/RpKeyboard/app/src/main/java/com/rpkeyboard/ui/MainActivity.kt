package com.rpkeyboard.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.rpkeyboard.RpApp
import com.rpkeyboard.data.ClipStore
import com.rpkeyboard.data.FolderEntity
import com.rpkeyboard.data.ImpFolder
import com.rpkeyboard.data.buildInfo
import com.rpkeyboard.data.KbSettings
import com.rpkeyboard.data.PRESET_MODES
import com.rpkeyboard.data.Prefs
import com.rpkeyboard.data.Repo
import com.rpkeyboard.data.Suggester
import com.rpkeyboard.data.TemplateEntity
import com.rpkeyboard.data.countFolders
import com.rpkeyboard.data.countTemplates
import com.rpkeyboard.data.descendants
import com.rpkeyboard.data.modeLabel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as RpApp
        setContent { App(app.repo, app.prefs, app.suggester, app.clips) }
    }
}

@Composable
fun App(repo: Repo, prefs: Prefs, suggester: Suggester, clips: ClipStore) {
    var settings by remember { mutableStateOf(prefs.load()) }
    var tab by remember { mutableIntStateOf(0) }
    val titles = listOf("Библиотека", "Импорт", "Настройки")
    val icons = listOf("📚", "💾", "⚙")
    RpTheme(settings.dark) {
        Scaffold(bottomBar = {
            NavigationBar {
                titles.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(icons[i]) }, label = { Text(t) }
                    )
                }
            }
        }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> EditorScreen(repo, settings.chatLimit)
                    1 -> FileScreen(repo)
                    else -> SettingsScreen(prefs, repo, suggester, clips, settings) { settings = it }
                }
            }
        }
    }
}

// ============================================================ Редактор библиотеки

sealed interface Dlg {
    data object NewFolder : Dlg
    data class RenameFolder(val f: FolderEntity) : Dlg
    data class DelFolder(val f: FolderEntity) : Dlg
    data class MoveFolder(val f: FolderEntity) : Dlg
    data object NewTpl : Dlg
    data class EditTpl(val t: TemplateEntity) : Dlg
    data class DelTpl(val t: TemplateEntity) : Dlg
    data class MoveTpl(val t: TemplateEntity) : Dlg
}

private fun pathOf(folders: List<FolderEntity>, id: Long?): String {
    val names = mutableListOf<String>()
    var c = id
    while (c != null) {
        val f = folders.firstOrNull { it.id == c } ?: break
        names.add(0, f.name)
        c = f.parentId
    }
    return "/" + names.joinToString("/")
}

@Composable
private fun Act(label: String, onClick: () -> Unit) {
    Text(label, Modifier.clickable { onClick() }.padding(horizontal = 12.dp, vertical = 8.dp))
}

@Composable
fun EditorScreen(repo: Repo, limit: Int) {
    val scope = rememberCoroutineScope()
    val folders by repo.folders.collectAsState(initial = emptyList())
    val templates by repo.templates.collectAsState(initial = emptyList())
    var cur by remember { mutableStateOf<Long?>(null) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    val subs = folders.filter { it.parentId == cur }
    val tpls = templates.filter { it.folderId == cur }
    val info = remember(folders, templates) { buildInfo(folders, templates) }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (cur != null) Act("←") { cur = folders.firstOrNull { it.id == cur }?.parentId }
            Text(pathOf(folders, cur), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { dlg = Dlg.NewFolder }) { Text("+ Папка") }
            OutlinedButton(onClick = { dlg = Dlg.NewTpl }) { Text("+ Шаблон") }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(subs, key = { "f${it.id}" }) { f ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(8.dp)) {
                        Text("📁 ${f.name}", Modifier.clickable { cur = f.id }.fillMaxWidth().padding(4.dp), fontWeight = FontWeight.Bold)
                        info[f.id]?.let { fi ->
                            Text(
                                "папок: ${fi.subs} · шаблонов: ${fi.templates}" +
                                    if (fi.names.isNotEmpty()) "\n" + fi.preview() else "",
                                Modifier.padding(horizontal = 4.dp),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Act("▲") { scope.launch { repo.shiftFolder(f, -1) } }
                            Act("▼") { scope.launch { repo.shiftFolder(f, 1) } }
                            Act("✎") { dlg = Dlg.RenameFolder(f) }
                            Act("⇄") { dlg = Dlg.MoveFolder(f) }
                            Act("🗑") { dlg = Dlg.DelFolder(f) }
                        }
                    }
                }
            }
            items(tpls, key = { "t${it.id}" }) { t ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(8.dp)) {
                        Text(
                            "${t.name}  ·  ${modeLabel(t.mode)}" + if (limit > 0 && t.text.length > limit) "  ⚠ ${t.text.length}" else "",
                            fontWeight = FontWeight.Bold
                        )
                        var expanded by remember(t.id) { mutableStateOf(false) }
                        Text(
                            t.text,
                            Modifier.fillMaxWidth().clickable { expanded = !expanded },
                            maxLines = if (expanded) Int.MAX_VALUE else 2,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Act(if (t.favorite) "★" else "☆") { scope.launch { repo.toggleFav(t) } }
                            Act("▲") { scope.launch { repo.shiftTemplate(t, -1) } }
                            Act("▼") { scope.launch { repo.shiftTemplate(t, 1) } }
                            Act("✎") { dlg = Dlg.EditTpl(t) }
                            Act("⇄") { dlg = Dlg.MoveTpl(t) }
                            Act("🗑") { dlg = Dlg.DelTpl(t) }
                        }
                    }
                }
            }
        }
    }

    when (val d = dlg) {
        null -> {}
        Dlg.NewFolder -> NameDialog("Новая папка", "", { n -> scope.launch { repo.addFolder(cur, n) }; dlg = null }) { dlg = null }
        is Dlg.RenameFolder -> NameDialog("Переименовать папку", d.f.name, { n -> scope.launch { repo.renameFolder(d.f, n) }; dlg = null }) { dlg = null }
        is Dlg.DelFolder -> ConfirmDialog("Удалить папку «${d.f.name}» со всем содержимым?", { scope.launch { repo.deleteFolder(d.f) }; dlg = null }) { dlg = null }
        is Dlg.MoveFolder -> PickDialog(folders, setOf(d.f.id) + descendants(folders, d.f.id), { target -> scope.launch { repo.moveFolderTo(d.f, target) }; dlg = null }) { dlg = null }
        Dlg.NewTpl -> TemplateDialog(null, limit, { n, x, m -> scope.launch { repo.saveTemplate(TemplateEntity(folderId = cur, name = n, text = x, mode = m)) }; dlg = null }) { dlg = null }
        is Dlg.EditTpl -> TemplateDialog(d.t, limit, { n, x, m -> scope.launch { repo.saveTemplate(d.t.copy(name = n, text = x, mode = m)) }; dlg = null }) { dlg = null }
        is Dlg.DelTpl -> ConfirmDialog("Удалить шаблон «${d.t.name}»?", { scope.launch { repo.deleteTemplate(d.t) }; dlg = null }) { dlg = null }
        is Dlg.MoveTpl -> PickDialog(folders, emptySet(), { target -> scope.launch { repo.moveTemplateTo(d.t, target) }; dlg = null }) { dlg = null }
    }
}

@Composable
private fun NameDialog(title: String, initial: String, onOk: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Название") }) },
        confirmButton = { TextButton(onClick = { onOk(name) }, enabled = name.isNotBlank()) { Text("Сохранить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun ConfirmDialog(text: String, onOk: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onOk) { Text("Удалить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun TemplateDialog(initial: TemplateEntity?, limit: Int, onOk: (String, String, String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var text by remember { mutableStateOf(initial?.text ?: "") }
    val startMode = initial?.mode ?: "action"
    var preset by remember { mutableStateOf(if (startMode in PRESET_MODES) startMode else "custom") }
    var custom by remember { mutableStateOf(if (startMode in PRESET_MODES) "" else startMode) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Новый шаблон" else "Шаблон") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Название кнопки") })
                OutlinedTextField(text, { text = it }, minLines = 3, label = { Text("Текст сообщения") })
                val over = limit > 0 && text.length > limit
                Text(
                    if (limit > 0) "${text.length} из $limit символов" + (if (over) " ⚠ длиннее лимита" else "") else "${text.length} символов",
                    color = if (over) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
                Text("Режим чата")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PRESET_MODES.forEach { m ->
                        FilterChip(selected = preset == m, onClick = { preset = m }, label = { Text(modeLabel(m)) })
                    }
                    FilterChip(selected = preset == "custom", onClick = { preset = "custom" }, label = { Text("Свой") })
                }
                if (preset == "custom") {
                    OutlinedTextField(custom, { custom = it }, singleLine = true, label = { Text("Название режима") })
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onOk(name.trim(), text, if (preset == "custom") custom.trim().ifBlank { "chat" } else preset) },
                enabled = name.isNotBlank() && text.isNotBlank()
            ) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

private fun flatten(all: List<FolderEntity>, parent: Long?, depth: Int, exclude: Set<Long>, out: MutableList<Pair<FolderEntity, Int>>) {
    all.filter { it.parentId == parent && it.id !in exclude }.forEach {
        out.add(it to depth)
        flatten(all, it.id, depth + 1, exclude, out)
    }
}

@Composable
private fun PickDialog(folders: List<FolderEntity>, exclude: Set<Long>, onPick: (Long?) -> Unit, onDismiss: () -> Unit) {
    val list = remember(folders, exclude) { mutableListOf<Pair<FolderEntity, Int>>().also { flatten(folders, null, 0, exclude, it) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Переместить в…") },
        text = {
            Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                Text("/ (корень)", Modifier.fillMaxWidth().clickable { onPick(null) }.padding(10.dp))
                list.forEach { (f, depth) ->
                    Text("📁 ${f.name}", Modifier.fillMaxWidth().clickable { onPick(f.id) }.padding(start = (10 + depth * 16).dp, top = 10.dp, bottom = 10.dp, end = 10.dp))
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

// ============================================================ Импорт / экспорт

private data class Pending(val tree: ImpFolder, val dups: Int)

@Composable
fun FileScreen(repo: Repo) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<Pending?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try {
                val json = repo.exportJson()
                withContext(Dispatchers.IO) {
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
                }
                msg = "Библиотека сохранена в файл"
            } catch (e: Exception) {
                msg = "Ошибка: ${e.message}"
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    ctx.contentResolver.openInputStream(uri)!!.bufferedReader().readText()
                }
                val tree = repo.parseLibrary(text)
                pending = Pending(tree, repo.countDuplicates(tree))
                msg = ""
            } catch (e: Exception) {
                msg = "Ошибка: ${e.message}"
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Импорт и экспорт (JSON)", style = MaterialTheme.typography.titleMedium)
        Text("Экспорт — это и есть резервная копия библиотеки. Сохраняйте файл в надёжное место.")
        Button(onClick = { exportLauncher.launch("rp-library.json") }, Modifier.fillMaxWidth()) { Text("Экспорт / резервная копия") }
        OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("Импорт из файла") }
        if (msg.isNotEmpty()) Text(msg)
    }

    val p = pending
    if (p != null) {
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Импорт библиотеки") },
            text = {
                Text("Папок: ${p.tree.countFolders()}, шаблонов: ${p.tree.countTemplates()}.\nДубликатов среди них: ${p.dups}.")
            },
            confirmButton = {
                Column {
                    TextButton(onClick = {
                        scope.launch { repo.import(p.tree, skipDuplicates = true, replace = false); msg = "Импортировано (дубликаты пропущены)" }
                        pending = null
                    }) { Text("Объединить, пропуская дубликаты") }
                    TextButton(onClick = {
                        scope.launch { repo.import(p.tree, skipDuplicates = false, replace = false); msg = "Импортировано" }
                        pending = null
                    }) { Text("Объединить, добавить всё") }
                    TextButton(onClick = {
                        scope.launch { repo.import(p.tree, skipDuplicates = false, replace = true); msg = "Библиотека заменена" }
                        pending = null
                    }) { Text("Заменить всю библиотеку") }
                }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Отмена") } }
        )
    }
}

// ============================================================ Настройки

@Composable
fun SettingsScreen(prefs: Prefs, repo: Repo, suggester: Suggester, clips: ClipStore, s: KbSettings, onChange: (KbSettings) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    fun upd(n: KbSettings) {
        prefs.save(n)
        onChange(n)
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("Установка", style = MaterialTheme.typography.titleMedium)
        Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }, Modifier.fillMaxWidth()) {
            Text("1. Включить RP Keyboard")
        }
        Button(onClick = {
            (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }, Modifier.fillMaxWidth()) { Text("2. Выбрать RP Keyboard") }
        HorizontalDivider()
        Text("Внешний вид", style = MaterialTheme.typography.titleMedium)
        SwitchRow("Тёмная тема", s.dark) { upd(s.copy(dark = it)) }
        SliderRow("Высота клавиатуры, dp", s.heightDp, 200..420) { upd(s.copy(heightDp = it)) }
        SliderRow("Высота в горизонтальном режиме, dp", s.heightLandDp, 120..300) { upd(s.copy(heightLandDp = it)) }
        SliderRow("Размер кнопок, dp", s.btnDp, 36..80) { upd(s.copy(btnDp = it)) }
        SliderRow("Размер текста, sp", s.textSp, 11..20) { upd(s.copy(textSp = it)) }
        SliderRow("Количество столбцов", s.columns, 1..4) { upd(s.copy(columns = it)) }
        SliderRow("Строк текста на кнопке (0 — скрыть)", s.previewLines, 0..4) { upd(s.copy(previewLines = it)) }
        HorizontalDivider()
        Text("Поведение", style = MaterialTheme.typography.titleMedium)
        SwitchRow("Подсказка режима чата (иначе — только текст)", s.hintMode) { upd(s.copy(hintMode = it)) }
        SwitchRow("Показывать «Недавние»", s.showRecents) { upd(s.copy(showRecents = it)) }
        SwitchRow("Показывать «Избранное»", s.showFavorites) { upd(s.copy(showFavorites = it)) }
        OutlinedButton(onClick = { scope.launch { repo.clearRecents() } }) { Text("Очистить недавние") }
        HorizontalDivider()
        Text("Подсказки и ввод", style = MaterialTheme.typography.titleMedium)
        SwitchRow("Подсказки слов", s.suggest) { upd(s.copy(suggest = it)) }
        SwitchRow("Автоисправление опечаток", s.autoCorrect) { upd(s.copy(autoCorrect = it)) }
        SwitchRow("Запоминать мои слова (только на телефоне)", s.learn) { upd(s.copy(learn = it)) }
        OutlinedButton(onClick = { suggester.clearLearned() }) { Text("Забыть выученные слова") }
        HorizontalDivider()
        Text("Буфер обмена и чат", style = MaterialTheme.typography.titleMedium)
        SwitchRow("История буфера обмена (хранится на телефоне)", s.clipboard) { upd(s.copy(clipboard = it)) }
        OutlinedButton(onClick = { clips.clearAll() }) { Text("Очистить историю буфера") }
        SliderRow("Лимит символов в чате (0 — выкл.)", s.chatLimit, 0..300) { upd(s.copy(chatLimit = it)) }
    }
}

@Composable
private fun SwitchRow(label: String, v: Boolean, onV: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = v, onCheckedChange = onV)
    }
}

@Composable
private fun SliderRow(label: String, v: Int, r: IntRange, onV: (Int) -> Unit) {
    Column {
        Text("$label: $v")
        Slider(value = v.toFloat(), onValueChange = { onV(it.toInt()) }, valueRange = r.first.toFloat()..r.last.toFloat())
    }
}
