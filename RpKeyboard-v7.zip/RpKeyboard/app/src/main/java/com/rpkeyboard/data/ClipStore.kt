package com.rpkeyboard.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ClipItem(val text: String, val pinned: Boolean = false)

/** История буфера обмена. Хранится только в файле на телефоне. */
class ClipStore(ctx: Context) {
    private val file = File(ctx.filesDir, "clipboard.json")
    private var items: List<ClipItem> = load()

    private fun load(): List<ClipItem> = try {
        if (!file.exists()) {
            emptyList()
        } else {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val t = o.optString("t", "")
                if (t.isEmpty()) null else ClipItem(t, o.optBoolean("p", false))
            }
        }
    } catch (_: Exception) {
        emptyList()
    }

    private fun save() {
        try {
            val arr = JSONArray()
            items.forEach { arr.put(JSONObject().put("t", it.text).put("p", it.pinned)) }
            file.writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    fun list(): List<ClipItem> = items

    fun add(text: String) {
        val t = text.trim()
        if (t.isEmpty() || t.length > 2000) return
        val old = items.firstOrNull { it.text == t }
        var unpinned = 0
        items = (listOf(ClipItem(t, old?.pinned ?: false)) + items.filter { it.text != t })
            .filter { it.pinned || ++unpinned <= 30 }
        save()
    }

    fun togglePin(text: String) {
        items = items.map { if (it.text == text) it.copy(pinned = !it.pinned) else it }
        save()
    }

    fun remove(text: String) {
        items = items.filter { it.text != text }
        save()
    }

    fun clearUnpinned() {
        items = items.filter { it.pinned }
        save()
    }

    fun clearAll() {
        items = emptyList()
        save()
    }
}
