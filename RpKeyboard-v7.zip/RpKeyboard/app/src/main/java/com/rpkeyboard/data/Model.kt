package com.rpkeyboard.data

import android.content.Context

val PRESET_MODES = listOf("event", "action", "try", "chat")

fun modeLabel(m: String): String = when (m) {
    "event" -> "Событие"
    "action" -> "Действие"
    "try" -> "Попытка"
    "chat" -> "Обычный чат"
    else -> m
}

data class KbSettings(
    val dark: Boolean = true,
    val heightDp: Int = 300,
    val btnDp: Int = 48,
    val textSp: Int = 14,
    val columns: Int = 2,
    val hintMode: Boolean = true,
    val showRecents: Boolean = true,
    val showFavorites: Boolean = true,
    val suggest: Boolean = true,
    val autoCorrect: Boolean = true,
    val learn: Boolean = true,
    val heightLandDp: Int = 180,
    val clipboard: Boolean = true,
    val chatLimit: Int = 0,
    val previewLines: Int = 2
)

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("rp_settings", Context.MODE_PRIVATE)

    fun load() = KbSettings(
        dark = p.getBoolean("dark", true),
        heightDp = p.getInt("height", 300),
        btnDp = p.getInt("btn", 48),
        textSp = p.getInt("text", 14),
        columns = p.getInt("cols", 2),
        hintMode = p.getBoolean("hint", true),
        showRecents = p.getBoolean("recents", true),
        showFavorites = p.getBoolean("favs", true),
        suggest = p.getBoolean("suggest", true),
        autoCorrect = p.getBoolean("autocorrect", true),
        learn = p.getBoolean("learn", true),
        heightLandDp = p.getInt("height_land", 180),
        clipboard = p.getBoolean("clipboard", true),
        chatLimit = p.getInt("chat_limit", 0),
        previewLines = p.getInt("preview", 2)
    )

    fun save(s: KbSettings) {
        p.edit()
            .putBoolean("dark", s.dark)
            .putInt("height", s.heightDp)
            .putInt("btn", s.btnDp)
            .putInt("text", s.textSp)
            .putInt("cols", s.columns)
            .putBoolean("hint", s.hintMode)
            .putBoolean("recents", s.showRecents)
            .putBoolean("favs", s.showFavorites)
            .putBoolean("suggest", s.suggest)
            .putBoolean("autocorrect", s.autoCorrect)
            .putBoolean("learn", s.learn)
            .putInt("height_land", s.heightLandDp)
            .putBoolean("clipboard", s.clipboard)
            .putInt("chat_limit", s.chatLimit)
            .putInt("preview", s.previewLines)
            .apply()
    }

    var lastFolder: Long?
        get() = p.getLong("lastFolder", -1L).takeIf { it >= 0 }
        set(v) { p.edit().putLong("lastFolder", v ?: -1L).apply() }

    var emojiRecent: String
        get() = p.getString("emoji_recent", "") ?: ""
        set(v) { p.edit().putString("emoji_recent", v).apply() }

    var seeded: Boolean
        get() = p.getBoolean("seeded", false)
        set(v) { p.edit().putBoolean("seeded", v).apply() }
}
