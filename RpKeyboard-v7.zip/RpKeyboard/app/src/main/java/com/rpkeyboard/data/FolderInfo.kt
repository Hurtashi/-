package com.rpkeyboard.data

/** Краткое содержимое папки: сколько внутри и несколько названий. */
data class FolderInfo(val subs: Int, val templates: Int, val names: List<String>) {
    fun preview(): String = names.take(3).joinToString(", ") + if (subs + templates > 3) "…" else ""
}

fun buildInfo(folders: List<FolderEntity>, templates: List<TemplateEntity>): Map<Long, FolderInfo> {
    val subs = folders.groupBy { it.parentId }
    val tpls = templates.groupBy { it.folderId }
    return folders.associate { f ->
        val sf = subs[f.id].orEmpty()
        val tt = tpls[f.id].orEmpty()
        f.id to FolderInfo(sf.size, tt.size, (sf.map { "📁" + it.name } + tt.map { it.name }).take(4))
    }
}
