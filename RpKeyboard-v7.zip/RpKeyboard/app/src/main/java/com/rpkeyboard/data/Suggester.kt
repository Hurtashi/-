package com.rpkeyboard.data

import android.content.Context
import java.io.File
import kotlin.math.abs

/**
 * Офлайн-подсказки и осторожное автоисправление.
 * Словари лежат в assets (words_ru.txt, words_en.txt: одно слово в строке, частые вперёд),
 * выученные слова хранятся только в файле на телефоне.
 */
class Suggester(private val ctx: Context) {
    private val dictRu: List<String> = loadAsset("words_ru.txt")
    private val dictEn: List<String> = loadAsset("words_en.txt")
    private val setRu = dictRu.toHashSet()
    private val setEn = dictEn.toHashSet()
    private val learned = HashMap<String, Int>()
    private val ignored = HashSet<String>()
    @Volatile private var lib: Set<String> = emptySet()
    private val file = File(ctx.filesDir, "learned.txt")
    private var dirty = 0

    init {
        try {
            if (file.exists()) {
                file.forEachLine { line ->
                    val p = line.split('\t')
                    if (p.size == 2) learned[p[0]] = p[1].toIntOrNull() ?: 1
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun loadAsset(name: String): List<String> = try {
        ctx.assets.open(name).bufferedReader().useLines { seq ->
            seq.map { it.trim() }.filter { it.isNotEmpty() }.toList()
        }
    } catch (_: Exception) {
        emptyList()
    }

    private fun isCyr(c: Char) = c in 'а'..'я' || c in 'А'..'Я' || c == 'ё' || c == 'Ё'

    fun isKnown(w: String): Boolean {
        val l = w.lowercase()
        return l in setRu || l in setEn || l in learned || l in lib || l in ignored
    }

    private fun applyCase(prefix: String, w: String): String = when {
        prefix.length > 1 && prefix.all { it.isUpperCase() } -> w.uppercase()
        prefix.isNotEmpty() && prefix[0].isUpperCase() -> w.replaceFirstChar { it.uppercase() }
        else -> w
    }

    fun suggest(prefix: String, limit: Int = 3): List<String> {
        if (prefix.isEmpty()) return emptyList()
        val p = prefix.lowercase()
        val cyr = isCyr(p[0])
        val dict = if (cyr) dictRu else dictEn
        val out = LinkedHashSet<String>()
        learned.entries
            .filter { it.key.startsWith(p) && it.key != p && isCyr(it.key[0]) == cyr }
            .sortedByDescending { it.value }
            .forEach { out.add(it.key) }
        lib.filter { it.startsWith(p) && it != p && isCyr(it[0]) == cyr }
            .sortedBy { it.length }
            .forEach { out.add(it) }
        for (w in dict) {
            if (out.size >= limit * 3) break
            if (w.startsWith(p) && w != p) out.add(w)
        }
        return out.take(limit).map { applyCase(prefix, it) }
    }

    /** Исправление только для явных опечаток в середине слова. Окончания не трогаем. */
    fun correction(word: String): String? {
        if (word.length < 5 || word.any { it.isDigit() } || isKnown(word)) return null
        if (word.drop(1).any { it.isUpperCase() }) return null
        val l = word.lowercase()
        val dict = if (isCyr(l[0])) dictRu else dictEn
        var best: String? = null
        var count = 0
        for (w in dict) {
            if (abs(w.length - l.length) > 1 || w[0] != l[0]) continue
            if (fixable(w, l)) {
                count++
                if (count > 1) return null
                best = w
            }
        }
        return best?.let { applyCase(word, it) }
    }

    /** true, если слово [typed] отличается от [dict] одной опечаткой не в последних двух буквах. */
    private fun fixable(dict: String, typed: String): Boolean {
        if (dict == typed) return false
        val ld = dict.length
        val lt = typed.length
        var i = 0
        val m = minOf(ld, lt)
        while (i < m && dict[i] == typed[i]) i++
        if (ld == lt) {
            if (i == ld) return false
            if (dict.substring(i + 1) == typed.substring(i + 1)) return i < ld - 2
            return i + 1 < ld && dict[i] == typed[i + 1] && dict[i + 1] == typed[i] &&
                dict.substring(i + 2) == typed.substring(i + 2)
        }
        val (s, l) = if (ld < lt) dict to typed else typed to dict
        return s.substring(i) == l.substring(i + 1) && i < l.length - 2
    }

    fun learn(word: String) {
        val l = word.lowercase()
        if (l.length < 2 || !l.all { it.isLetter() }) return
        learned[l] = (learned[l] ?: 0) + 1
        if (++dirty >= 20) save()
    }

    fun ignore(word: String) {
        ignored.add(word.lowercase())
    }

    fun setLibrary(texts: List<String>) {
        val re = Regex("\\p{L}+")
        val s = HashSet<String>()
        texts.forEach { t -> re.findAll(t).forEach { m -> if (m.value.length >= 2) s.add(m.value.lowercase()) } }
        lib = s
    }

    fun save() {
        try {
            file.writeText(learned.entries.joinToString("\n") { "${it.key}\t${it.value}" })
            dirty = 0
        } catch (_: Exception) {
        }
    }

    fun clearLearned() {
        learned.clear()
        ignored.clear()
        try {
            file.delete()
        } catch (_: Exception) {
        }
    }
}
