package com.rpkeyboard.ime

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items as listItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import android.view.HapticFeedbackConstants
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rpkeyboard.data.ClipItem
import com.rpkeyboard.data.FolderEntity
import com.rpkeyboard.data.FolderInfo
import com.rpkeyboard.data.buildInfo
import com.rpkeyboard.data.KbSettings
import com.rpkeyboard.data.Repo
import com.rpkeyboard.data.TemplateEntity
import com.rpkeyboard.data.modeLabel
import kotlin.math.abs
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class Screen { FOLDER, FAVORITES, RECENTS, SEARCH }

class KbState {
    var settings by mutableStateOf(KbSettings())
    var rp by mutableStateOf(false)
    var password by mutableStateOf(false)
    var screen by mutableStateOf(Screen.FOLDER)
    var folderId by mutableStateOf<Long?>(null)
    var query by mutableStateOf("")
    var hint by mutableStateOf<String?>(null)
    var emoji by mutableStateOf(false)
    var clip by mutableStateOf(false)
    var clips by mutableStateOf<List<ClipItem>>(emptyList())
    var emojiRecent by mutableStateOf<List<String>>(emptyList())
    var hintWarn by mutableStateOf(false)

    fun pushEmoji(e: String) {
        emojiRecent = (listOf(e) + emojiRecent.filter { it != e }).take(24)
    }
    var ru by mutableStateOf(true)
    var suggestions by mutableStateOf<List<String>>(emptyList())
    var autoShift by mutableStateOf(false)

    fun back(folders: List<FolderEntity>) {
        if (screen != Screen.FOLDER) {
            screen = Screen.FOLDER
            query = ""
        } else {
            val id = folderId ?: return
            folderId = folders.firstOrNull { it.id == id }?.parentId
        }
    }

    fun title(folders: List<FolderEntity>): String = when (screen) {
        Screen.FAVORITES -> "★ Избранное"
        Screen.RECENTS -> "🕘 Недавние"
        Screen.SEARCH -> "Поиск"
        Screen.FOLDER -> folderId?.let { id -> folders.firstOrNull { it.id == id }?.name } ?: "Библиотека"
    }
}

class KeyActions(
    val type: (String) -> Unit,
    val backspace: () -> Unit,
    val enter: () -> Unit,
    val insert: (TemplateEntity) -> Unit,
    val toggleFav: (TemplateEntity) -> Unit,
    val openSettings: () -> Unit,
    val pickSuggestion: (String) -> Unit,
    val paste: (String) -> Unit,
    val clipPin: (ClipItem) -> Unit,
    val clipDelete: (ClipItem) -> Unit,
    val clipClear: () -> Unit
)

sealed class GridItem(val key: String) {
    class F(val f: FolderEntity) : GridItem("f${f.id}")
    class V(val screen: Screen, val label: String) : GridItem("v${screen.name}")
    class T(val t: TemplateEntity) : GridItem("t${t.id}")
}

@Composable
fun KeyboardRoot(ks: KbState, repo: Repo, act: KeyActions) {
    val s = ks.settings
    val folders by repo.folders.collectAsState(initial = emptyList())
    val templates by repo.templates.collectAsState(initial = emptyList())
    val recents by repo.recents.collectAsState(initial = emptyList())
    val showRp = ks.rp && !ks.password
    val cfg = LocalConfiguration.current
    val land = cfg.screenHeightDp < cfg.screenWidthDp
    val searching = showRp && ks.screen == Screen.SEARCH
    // В горизонтальном режиме клавиатура ниже, чтобы не закрывать игру.
    val heightDp = (if (land) (if (searching) 250 else s.heightLandDp) else s.heightDp)
        .coerceAtMost((cfg.screenHeightDp * 0.75f).toInt())

    Column(
        Modifier
            .fillMaxWidth()
            .height(heightDp.dp)
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 4.dp, vertical = 3.dp)
    ) {
        TopBar(ks, showRp, folders, act)
        Spacer(Modifier.height(3.dp))
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (showRp) RpPanel(ks, folders, templates, recents, act)
            else if (ks.clip) ClipPanel(Modifier.fillMaxSize(), ks, act) { ks.clip = false }
            else if (ks.emoji) EmojiPanel(
                Modifier.fillMaxSize(), ks.emojiRecent,
                { e ->
                    act.type(e)
                    ks.pushEmoji(e)
                },
                act.backspace
            ) { ks.emoji = false }
            else TypingKeyboard(
                Modifier.fillMaxSize(), act.type, act.backspace, act.enter, ks.autoShift,
                ru = ks.ru, onLang = { ks.ru = !ks.ru }
            )
        }
    }
}

@Composable
private fun TopBar(ks: KbState, showRp: Boolean, folders: List<FolderEntity>, act: KeyActions) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().height(40.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (!ks.password) BarBtn(if (ks.rp) "ABC" else "RP", accent = true) {
            ks.rp = !ks.rp
            ks.emoji = false
            ks.clip = false
        }
        if (showRp) {
            BarBtn("🔍") {
                ks.screen = if (ks.screen == Screen.SEARCH) Screen.FOLDER else Screen.SEARCH
                ks.query = ""
            }
            BarBtn("★") { ks.screen = Screen.FAVORITES }
            BarBtn("←") { ks.back(folders) }
            Text(
                ks.title(folders),
                Modifier.weight(1f).padding(horizontal = 6.dp),
                fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant
            )
        } else if (ks.suggestions.isNotEmpty()) {
            ks.suggestions.forEach { sg ->
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(8.dp))
                        .background(cs.secondaryContainer)
                        .tap { act.pickSuggestion(sg) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        sg, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = cs.onSecondaryContainer
                    )
                }
            }
        } else {
            Spacer(Modifier.weight(1f))
            BarBtn("📋", flat = true) {
                ks.clip = !ks.clip
                ks.emoji = false
            }
            BarBtn("😊", flat = true) {
                ks.emoji = !ks.emoji
                ks.clip = false
            }
        }
        if (showRp || ks.suggestions.isEmpty()) BarBtn("⚙", flat = !showRp) { act.openSettings() }
    }
}

@Composable
private fun BarBtn(label: String, accent: Boolean = false, flat: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .width(44.dp)
            .fillMaxHeight()
            .clip(RoundedCornerShape(10.dp))
            .background(if (flat) Color.Transparent else if (accent) cs.primary else cs.surfaceVariant)
            .tap { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, fontSize = if (flat) 20.sp else 15.sp, fontWeight = FontWeight.Bold,
            color = if (accent) cs.onPrimary else cs.onSurface
        )
    }
}

@Composable
private fun RpPanel(
    ks: KbState,
    folders: List<FolderEntity>,
    templates: List<TemplateEntity>,
    recents: List<TemplateEntity>,
    act: KeyActions
) {
    val s = ks.settings
    val cs = MaterialTheme.colorScheme
    val cfg = LocalConfiguration.current
    val land = cfg.screenHeightDp < cfg.screenWidthDp
    val info = remember(folders, templates) { buildInfo(folders, templates) }
    Column(Modifier.fillMaxSize()) {
        val h = ks.hint
        if (h != null && (s.hintMode || ks.hintWarn)) {
            Text(
                h, Modifier.fillMaxWidth().padding(bottom = 2.dp, start = 4.dp),
                fontSize = 12.sp, color = if (ks.hintWarn) cs.error else cs.primary, maxLines = 1
            )
        }
        if (ks.screen == Screen.SEARCH) {
            Box(
                Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(8.dp))
                    .background(cs.surfaceVariant).padding(horizontal = 10.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    if (ks.query.isEmpty()) "Поиск по шаблонам и папкам…" else ks.query,
                    fontSize = 14.sp,
                    color = if (ks.query.isEmpty()) cs.onSurfaceVariant else cs.onSurface,
                    maxLines = 1
                )
            }
            Spacer(Modifier.height(3.dp))
            val results = remember(ks.query, templates, folders) { search(ks.query, templates, folders) }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                CardGrid(results.map { GridItem.T(it) }, ks, act, info)
            }
            Spacer(Modifier.height(3.dp))
            TypingKeyboard(
                Modifier.fillMaxWidth().height(if (land) 110.dp else 172.dp),
                { ks.query += it },
                { ks.query = ks.query.dropLast(1) },
                null,
                numberRow = false,
                ru = ks.ru,
                onLang = { ks.ru = !ks.ru }
            )
        } else {
            val items = remember(ks.screen, ks.folderId, folders, templates, recents, s.showFavorites, s.showRecents) {
                when (ks.screen) {
                    Screen.FAVORITES -> templates.filter { it.favorite }.map { GridItem.T(it) }
                    Screen.RECENTS -> recents.map { GridItem.T(it) }
                    else -> buildList<GridItem> {
                        if (ks.folderId == null) {
                            if (s.showFavorites) add(GridItem.V(Screen.FAVORITES, "★ Избранное"))
                            if (s.showRecents) add(GridItem.V(Screen.RECENTS, "🕘 Недавние"))
                        }
                        folders.filter { it.parentId == ks.folderId }.forEach { add(GridItem.F(it)) }
                        templates.filter { it.folderId == ks.folderId }.forEach { add(GridItem.T(it)) }
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) { CardGrid(items, ks, act, info) }
        }
    }
}

private fun search(q: String, templates: List<TemplateEntity>, folders: List<FolderEntity>): List<TemplateEntity> {
    val query = q.trim().lowercase()
    if (query.isEmpty()) return emptyList()
    val names = folders.associate { it.id to it.name.lowercase() }
    return templates.filter {
        it.name.lowercase().contains(query) ||
            it.text.lowercase().contains(query) ||
            (it.folderId?.let { id -> names[id] }?.contains(query) == true)
    }
}

@Composable
private fun CardGrid(list: List<GridItem>, ks: KbState, act: KeyActions, info: Map<Long, FolderInfo>) {
    val s = ks.settings
    val cfg = LocalConfiguration.current
    val land = cfg.screenHeightDp < cfg.screenWidthDp
    val cols = if (land) (s.columns + 2).coerceAtMost(6) else s.columns
    LazyVerticalGrid(
        columns = GridCells.Fixed(cols),
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items(list, key = { it.key }) { item ->
            when (item) {
                is GridItem.F -> {
                    val fi = info[item.f.id]
                    Card(
                        "📁 ${item.f.name}",
                        fi?.preview()?.ifEmpty { null },
                        fi?.let { "папок: ${it.subs} · шаблонов: ${it.templates}" },
                        true, s,
                        {
                            ks.folderId = item.f.id
                            ks.screen = Screen.FOLDER
                        },
                        null
                    )
                }
                is GridItem.V -> Card(item.label, null, null, true, s, { ks.screen = item.screen }, null)
                is GridItem.T -> {
                    val len = item.t.text.length
                    val over = s.chatLimit > 0 && len > s.chatLimit
                    val sub = listOfNotNull(
                        if (s.hintMode) modeLabel(item.t.mode) else null,
                        if (over) "⚠ $len/${s.chatLimit}" else null
                    ).joinToString(" · ").ifEmpty { null }
                    Card(
                        (if (item.t.favorite) "★ " else "") + item.t.name,
                        item.t.text, sub, false, s,
                        { act.insert(item.t) },
                        { act.toggleFav(item.t) }
                    )
                }
            }
        }
    }
}

@Composable
private fun Card(
    text: String, body: String?, sub: String?, accent: Boolean, s: KbSettings,
    onTap: () -> Unit, onLong: (() -> Unit)?
) {
    val cs = MaterialTheme.colorScheme
    val showBody = body != null && s.previewLines > 0
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(min = s.btnDp.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (accent) cs.secondaryContainer else cs.surfaceVariant)
            .tap(onLong, onTap)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text, fontSize = s.textSp.sp,
            fontWeight = if (showBody) FontWeight.Medium else FontWeight.Normal,
            color = if (accent) cs.onSecondaryContainer else cs.onSurface,
            maxLines = if (showBody) 2 else 3, overflow = TextOverflow.Ellipsis
        )
        if (showBody) {
            Text(
                body!!, fontSize = (s.textSp - 2).coerceAtLeast(9).sp,
                color = cs.onSurfaceVariant, maxLines = s.previewLines, overflow = TextOverflow.Ellipsis
            )
        }
        if (sub != null) Text(sub, fontSize = (s.textSp - 4).coerceAtLeast(9).sp, color = cs.primary)
    }
}

// ---------------------------------------------------------------- клавиатура для набора

private const val NUM = "1234567890"
/** Долгое нажатие на букву: дополнительная буква (вместе со значком-цифрой появляется панель выбора). */
private val ALT = mapOf("е" to "ё")
private val RU = listOf("йцукенгшщзх", "фывапролджэ", "ячсмитьбю")
private val EN = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")

/** Мелкие значки в углу клавиш; долгое нажатие вводит этот символ. */
private val DIGITS = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
private val RU_H = listOf(
    DIGITS + "",
    listOf("@", "#", "₽", "%", "&", "-", "+", "(", ")", "/", "~"),
    listOf("*", "\"", "'", ":", ";", "!", "ъ", "?", "_")
)
private val EN_H = listOf(
    DIGITS,
    listOf("@", "#", "₽", "%", "&", "-", "+", "(", ")"),
    listOf("*", "\"", "'", ":", ";", "!", "?")
)
private val SYM = listOf("1234567890", "@#₽%&-+()/", "ё*\"':;!?_")

@Composable
fun TypingKeyboard(
    modifier: Modifier,
    onChar: (String) -> Unit,
    onBack: () -> Unit,
    onEnter: (() -> Unit)?,
    autoShift: Boolean = false,
    numberRow: Boolean = false,
    ru: Boolean = true,
    onLang: () -> Unit = {}
) {
    val cs = MaterialTheme.colorScheme
    var shift by remember { mutableIntStateOf(0) } // 0 выкл, 1 одна буква, 2 caps lock
    var lastShiftTap by remember { mutableLongStateOf(0L) }
    var sym by remember { mutableStateOf(false) }
    var popup by remember { mutableStateOf<List<String>>(emptyList()) }
    LaunchedEffect(autoShift) { if (autoShift && shift == 0) shift = 1 }
    LaunchedEffect(popup) {
        if (popup.isNotEmpty()) {
            delay(3000)
            popup = emptyList()
        }
    }

    fun emit(t: String) {
        popup = emptyList()
        onChar(t)
    }

    val rows = if (sym) SYM else if (ru) RU else EN
    val hints = if (ru) RU_H else EN_H
    val upper = shift != 0 && !sym

    Box(modifier) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            if (numberRow) {
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    NUM.forEach { d -> Key(d.toString()) { emit(d.toString()) } }
                }
            }
            rows.forEachIndexed { i, row ->
                Row(
                    Modifier.fillMaxWidth().weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    if (i == 2) {
                        if (sym) {
                            Spacer(Modifier.weight(1.3f))
                        } else {
                            Key(if (shift == 0) "⇧" else if (shift == 1) "⬆" else "⇪", 1.3f, true, lit = shift != 0) {
                                val now = System.currentTimeMillis()
                                shift = when {
                                    shift == 0 -> 1
                                    shift == 1 && now - lastShiftTap < 350 -> 2
                                    else -> 0
                                }
                                lastShiftTap = now
                            }
                        }
                    }
                    row.forEachIndexed { idx, c ->
                        val base = c.toString()
                        val out = if (upper) base.uppercase() else base
                        val h = if (sym) "" else hints[i].getOrElse(idx) { "" }
                        val hOut = if (upper && h.isNotEmpty() && h[0].isLetter()) h.uppercase() else h
                        val altRaw = if (ru && !sym) ALT[base] else null
                        val alt = altRaw?.let { if (upper) it.uppercase() else it }
                        val opts = listOfNotNull(alt, hOut.ifEmpty { null }).distinct()
                        val longAction: (() -> Unit)? = when {
                            opts.isEmpty() -> null
                            opts.size == 1 -> fun() {
                                emit(opts[0])
                                if (shift == 1) shift = 0
                            }
                            else -> fun() { popup = opts }
                        }
                        Key(out, hint = hOut.ifEmpty { null }, onLong = longAction) {
                            emit(out)
                            if (shift == 1) shift = 0
                        }
                    }
                    if (i == 2) BackKey(1.3f, onBack)
                }
            }
            Row(
                Modifier.fillMaxWidth().weight(1f),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Key(if (sym) "АБВ" else "#1?", 1.2f, true) { sym = !sym }
                Key("🌐", 1.1f, true) {
                    onLang()
                    sym = false
                }
                Key(",") { emit(",") }
                Key(
                    if (ru) "‹ Русский ›" else "‹ English ›", 4.4f,
                    onSwipe = {
                        onLang()
                        sym = false
                    }
                ) { emit(" ") }
                Key(".") { emit(".") }
                if (onEnter != null) Key("↵", 1.5f, true, active = true) {
                    popup = emptyList()
                    onEnter()
                }
            }
        }
        if (popup.isNotEmpty()) {
            Row(
                Modifier
                    .align(Alignment.TopCenter)
                    .clip(RoundedCornerShape(12.dp))
                    .background(cs.primary)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                popup.forEach { o ->
                    Box(
                        Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(cs.onPrimary.copy(alpha = 0.15f))
                            .tap {
                                emit(o)
                                if (shift == 1) shift = 0
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(o, fontSize = 24.sp, color = cs.onPrimary)
                    }
                }
            }
        }
    }
}

private fun em(s: String) = s.split(" ").filter { it.isNotEmpty() }

private val EMOJI_CATS: List<Pair<String, List<String>>> = listOf(
    "😀" to em("😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😋 😛 😜 🤪 😝 🤑 🤗 🤔 🤨 😐 😑 😶 😏 😒 🙄 😬 😮 😲 😳 🥺 😢 😭 😤 😠 😡 🤬 😱 😨 😰 😥 😓 🥱 😴 😷 🤒 🤕 🤢 🤮 🥵 🥶 😎 🤓 🧐"),
    "👍" to em("👍 👎 👌 🤌 🤏 ✌\uFE0F 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝\uFE0F 👋 🤚 🖐\uFE0F ✋ 🖖 👏 🙌 👐 🤲 🤝 🙏 ✍\uFE0F 💪 🦾 👀 👂 👃 👅 👄 🧠"),
    "❤\uFE0F" to em("❤\uFE0F 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 💕 💞 💓 💗 💖 💘 💝 💯 💢 💥 💫 💦 💨 🔥 ⭐ 🌟 ✨ ⚡ ✅ ❌ ❓ ❗ ‼\uFE0F ⚠\uFE0F 🚫 🔞 🆗 🆘 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪"),
    "👮" to em("👮 🕵\uFE0F 🚨 🚔 🚓 🚑 🚒 🚁 🏥 🏦 🏛\uFE0F ⚖\uFE0F 📄 📋 📝 📞 📱 💻 🔑 🔒 🔓 🛡\uFE0F 💰 💵 💳 🧾 💊 💉 🩺 🩹 🔧 🔨 🔦 📻 📢 📣 🪪"),
    "🚗" to em("🚗 🚕 🚙 🏎\uFE0F 🚌 🚎 🚐 🚚 🚛 🚜 🏍\uFE0F 🛵 🚲 🛴 ✈\uFE0F 🚤 ⛵ 🚢 🏠 🏢 🏪 🏬 🏨 ⛽ 🚦 🚧 🌆 🌃 🌉 🗺\uFE0F"),
    "🍔" to em("🍔 🍟 🍕 🌭 🥪 🌮 🌯 🍗 🥩 🍖 🍳 🥞 🍞 🥐 🧀 🥗 🍝 🍣 🍜 🍩 🍪 🎂 🍫 🍬 🍦 ☕ 🍵 🥤 🍺 🍻 🥂 🍷 🍸 🥃 🍎 🍌 🍉 🍇 🍓 🍒 🍑 🥕 🌽"),
    "🐶" to em("🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🦅 🦉 🐺 🐴 🦄 🐝 🦋 🐢 🐍 🐟 🐬 🌳 🌲 🌴 🌵 🌸 🌹 🌻 🌙 ☀\uFE0F ⛅ ❄\uFE0F ⛄ 🌈 🌊")
)

@Composable
fun EmojiPanel(
    modifier: Modifier,
    recent: List<String>,
    onPick: (String) -> Unit,
    onBack: () -> Unit,
    onClose: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    var cat by remember { mutableIntStateOf(if (recent.isNotEmpty()) 0 else 1) }
    val list = if (cat == 0) recent else EMOJI_CATS[cat - 1].second
    Column(modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(Modifier.fillMaxWidth().height(36.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            (listOf("🕘") + EMOJI_CATS.map { it.first }).forEachIndexed { i, icon ->
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (i == cat) cs.secondaryContainer else Color.Transparent)
                        .tap { cat = i },
                    contentAlignment = Alignment.Center
                ) { Text(icon, fontSize = 18.sp) }
            }
        }
        if (list.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("Пока пусто", color = cs.onSurfaceVariant, fontSize = 14.sp)
            }
        } else {
            LazyVerticalGrid(columns = GridCells.Fixed(8), modifier = Modifier.weight(1f).fillMaxWidth()) {
                items(list) { e ->
                    Box(Modifier.height(44.dp).tap { onPick(e) }, contentAlignment = Alignment.Center) {
                        Text(e, fontSize = 24.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().height(44.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            Key("ABC", 1.5f, true) { onClose() }
            Spacer(Modifier.weight(5f))
            BackKey(1.5f, onBack)
        }
    }
}

@Composable
private fun ClipPanel(modifier: Modifier, ks: KbState, act: KeyActions, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val list = remember(ks.clips) { ks.clips.sortedByDescending { it.pinned } }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (!ks.settings.clipboard) {
                Text(
                    "История буфера выключена в настройках приложения.",
                    Modifier.align(Alignment.Center).padding(16.dp), color = cs.onSurfaceVariant, fontSize = 14.sp
                )
            } else if (list.isEmpty()) {
                Text(
                    "Буфер пуст. Скопируйте текст, и он появится здесь.",
                    Modifier.align(Alignment.Center).padding(16.dp), color = cs.onSurfaceVariant, fontSize = 14.sp
                )
            } else {
                LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    listItems(list, key = { it.text }) { c ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                c.text,
                                Modifier.weight(1f).tap { act.paste(c.text) }.padding(10.dp),
                                fontSize = ks.settings.textSp.sp, maxLines = 3,
                                overflow = TextOverflow.Ellipsis, color = cs.onSurface
                            )
                            Text(if (c.pinned) "📌" else "📍", Modifier.tap { act.clipPin(c) }.padding(10.dp), fontSize = 16.sp)
                            Text("✕", Modifier.tap { act.clipDelete(c) }.padding(10.dp), fontSize = 16.sp, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().height(44.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            Key("ABC", 1.5f, true) { onClose() }
            Key("Очистить", 2f) { act.clipClear() }
            Spacer(Modifier.weight(3f))
            BackKey(1.5f, act.backspace)
        }
    }
}

@Composable
private fun RowScope.Key(
    label: String,
    weight: Float = 1f,
    special: Boolean = false,
    active: Boolean = false,
    lit: Boolean = false,
    hint: String? = null,
    onLong: (() -> Unit)? = null,
    onSwipe: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val view = LocalView.current
    val swipeCb = rememberUpdatedState(onSwipe)
    val tapCb = rememberUpdatedState(onClick)
    val longCb = rememberUpdatedState(onLong)
    var pressed by remember { mutableStateOf(false) }
    val bg = when {
        active -> if (pressed) cs.primary.copy(alpha = 0.7f) else cs.primary
        lit -> cs.primary.copy(alpha = 0.35f)
        special -> if (pressed) cs.surfaceVariant else cs.secondaryContainer
        else -> if (pressed) cs.secondaryContainer else cs.surfaceVariant
    }
    val swipeMod = if (onSwipe != null) {
        Modifier.pointerInput(Unit) {
            var acc = 0f
            var fired = false
            val threshold = 50.dp.toPx()
            detectHorizontalDragGestures(
                onDragStart = {
                    acc = 0f
                    fired = false
                },
                onHorizontalDrag = { change, dx ->
                    change.consume()
                    acc += dx
                    if (!fired && abs(acc) > threshold) {
                        fired = true
                        swipeCb.value?.invoke()
                    }
                }
            )
        }
    } else Modifier
    Box(
        Modifier
            .weight(weight)
            .fillMaxHeight()
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .then(swipeMod)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onLongPress = { longCb.value?.invoke() },
                    onTap = {
                        view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        tapCb.value()
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, fontSize = 18.sp, maxLines = 1,
            color = if (active) cs.onPrimary else if (special) cs.onSecondaryContainer else cs.onSurface
        )
        if (hint != null) {
            Text(
                hint, Modifier.align(Alignment.TopEnd).padding(top = 2.dp, end = 4.dp),
                fontSize = 9.sp, color = cs.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun RowScope.BackKey(weight: Float, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val view = LocalView.current
    val cb = rememberUpdatedState(onBack)
    val scope = rememberCoroutineScope()
    var pressed by remember { mutableStateOf(false) }
    Box(
        Modifier
            .weight(weight)
            .fillMaxHeight()
            .clip(RoundedCornerShape(8.dp))
            .background(if (pressed) cs.surfaceVariant else cs.secondaryContainer)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    pressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    cb.value()
                    val job = scope.launch {
                        delay(400)
                        while (true) {
                            cb.value()
                            delay(55)
                        }
                    }
                    tryAwaitRelease()
                    job.cancel()
                    pressed = false
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Text("⌫", fontSize = 18.sp, color = cs.onSecondaryContainer)
    }
}
