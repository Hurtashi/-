package com.rpkeyboard.ime

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.inputmethodservice.InputMethodService
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.rpkeyboard.RpApp
import com.rpkeyboard.data.Prefs
import com.rpkeyboard.data.TemplateEntity
import com.rpkeyboard.data.modeLabel
import com.rpkeyboard.ui.MainActivity
import com.rpkeyboard.ui.RpTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class RpImeService : InputMethodService(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry

    private val ks = KbState()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val repo by lazy { (application as RpApp).repo }
    private lateinit var prefs: Prefs
    private val suggester by lazy { (application as RpApp).suggester }
    private val clips by lazy { (application as RpApp).clips }
    private var clipListener: ClipboardManager.OnPrimaryClipChangedListener? = null
    private var undo: Triple<String, String, String>? = null
    private var smart = true
    private var learnOk = true

    override fun onCreate() {
        super.onCreate()
        savedStateController.performAttach()
        savedStateController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        prefs = (application as RpApp).prefs
        ks.settings = prefs.load()
        ks.folderId = prefs.lastFolder
        ks.clips = clips.list()
        ks.emojiRecent = prefs.emojiRecent.split(" ").filter { it.isNotEmpty() }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val listener = ClipboardManager.OnPrimaryClipChangedListener { onClipChanged(cm) }
        clipListener = listener
        cm.addPrimaryClipChangedListener(listener)
        scope.launch {
            repo.templates.collect { list -> suggester.setLibrary(list.map { it.name + " " + it.text }) }
        }
    }

    override fun onCreateInputView(): View {
        window.window?.decorView?.let { decor ->
            decor.setViewTreeLifecycleOwner(this)
            decor.setViewTreeViewModelStoreOwner(this)
            decor.setViewTreeSavedStateRegistryOwner(this)
        }
        val actions = KeyActions(
            type = { s -> typeText(s) },
            backspace = { doBackspace() },
            enter = { doEnter() },
            pickSuggestion = { sg -> pickSuggestion(sg) },
            paste = { t -> pasteText(t) },
            clipPin = { c ->
                clips.togglePin(c.text)
                ks.clips = clips.list()
            },
            clipDelete = { c ->
                clips.remove(c.text)
                ks.clips = clips.list()
            },
            clipClear = {
                clips.clearUnpinned()
                ks.clips = clips.list()
            },
            insert = { t -> insertTemplate(t) },
            toggleFav = { t -> scope.launch { repo.toggleFav(t) } },
            openSettings = {
                startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        )
        val view = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent { RpTheme(ks.settings.dark) { KeyboardRoot(ks, repo, actions) } }
        }
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
        return view
    }

    /** Не уходить в полноэкранный режим в ландшафте — важно для игр. */
    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        ks.settings = prefs.load()
        ks.password = isPassword(info)
        if (ks.password) ks.rp = false
        smart = isSmartField(info)
        learnOk = !ks.password &&
            ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING) == 0
        undo = null
        ks.clips = clips.list()
        refresh()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        prefs.lastFolder = ks.folderId
        suggester.save()
        prefs.emojiRecent = ks.emojiRecent.joinToString(" ")
    }

    override fun onDestroy() {
        clipListener?.let { (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).removePrimaryClipChangedListener(it) }
        prefs.emojiRecent = ks.emojiRecent.joinToString(" ")
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        store.clear()
        suggester.save()
        scope.cancel()
        super.onDestroy()
    }

    /** Авто-заглавная буква в начале предложения (как у обычных клавиатур). */
    private fun updateCaps() {
        val ic = currentInputConnection
        val info = currentInputEditorInfo
        ks.autoShift = ic != null && info != null && info.inputType != 0 &&
            ic.getCursorCapsMode(info.inputType) != 0
    }

    private fun wordBeforeCursor(): String {
        val t = currentInputConnection?.getTextBeforeCursor(40, 0) ?: return ""
        var i = t.length
        while (i > 0 && t[i - 1].isLetter()) i--
        return t.substring(i)
    }

    private fun refresh() {
        updateCaps()
        ks.suggestions = if (ks.settings.suggest && smart && !ks.rp) {
            suggester.suggest(wordBeforeCursor())
        } else emptyList()
    }

    private fun typeText(s: String) {
        val ic = currentInputConnection ?: return
        undo = null
        val boundary = s.length == 1 && !s[0].isLetterOrDigit()
        if (boundary && smart) {
            val w = wordBeforeCursor()
            val fix = if (w.isNotEmpty() && ks.settings.autoCorrect) suggester.correction(w) else null
            if (fix != null) {
                ic.deleteSurroundingText(w.length, 0)
                ic.commitText(fix + s, 1)
                undo = Triple(w, fix, s)
            } else {
                if (w.isNotEmpty() && learnOk && ks.settings.learn) suggester.learn(w)
                ic.commitText(s, 1)
            }
        } else {
            ic.commitText(s, 1)
        }
        refresh()
    }

    /** Backspace сразу после автоисправления возвращает слово, как вы его напечатали. */
    private fun doBackspace() {
        val ic = currentInputConnection
        val u = undo
        undo = null
        if (u != null && ic != null) {
            ic.deleteSurroundingText(u.second.length + u.third.length, 0)
            ic.commitText(u.first, 1)
            suggester.ignore(u.first)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        refresh()
    }

    private fun pasteText(t: String) {
        undo = null
        currentInputConnection?.commitText(t, 1)
        refresh()
    }

    private fun onClipChanged(cm: ClipboardManager) {
        if (!ks.settings.clipboard || ks.password) return
        try {
            val clip = cm.primaryClip ?: return
            val sensitive = Build.VERSION.SDK_INT >= 28 &&
                clip.description.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true
            if (sensitive) return
            val text = clip.getItemAt(0)?.coerceToText(this)?.toString() ?: return
            clips.add(text)
            ks.clips = clips.list()
        } catch (_: Exception) {
        }
    }

    private fun pickSuggestion(sg: String) {
        val ic = currentInputConnection ?: return
        val w = wordBeforeCursor()
        ic.deleteSurroundingText(w.length, 0)
        ic.commitText("$sg ", 1)
        undo = null
        if (learnOk && ks.settings.learn) suggester.learn(sg)
        refresh()
    }

    private fun isSmartField(info: EditorInfo?): Boolean {
        val t = info?.inputType ?: return true
        if (t == 0) return true
        if ((t and InputType.TYPE_MASK_CLASS) != InputType.TYPE_CLASS_TEXT) return false
        val v = t and InputType.TYPE_MASK_VARIATION
        return v == InputType.TYPE_TEXT_VARIATION_NORMAL ||
            v == InputType.TYPE_TEXT_VARIATION_SHORT_MESSAGE ||
            v == InputType.TYPE_TEXT_VARIATION_LONG_MESSAGE
    }

    /** Вставляет только текст шаблона. Ничего не отправляет. */
    private fun insertTemplate(t: TemplateEntity) {
        undo = null
        currentInputConnection?.commitText(t.text, 1)
        ks.suggestions = emptyList()
        val limit = ks.settings.chatLimit
        val over = limit > 0 && t.text.length > limit
        val parts = mutableListOf<String>()
        if (ks.settings.hintMode) parts.add("Режим чата: ${modeLabel(t.mode)}")
        if (over) parts.add("⚠ ${t.text.length} из $limit символов")
        ks.hintWarn = over
        ks.hint = parts.joinToString(" · ").ifEmpty { null }
        scope.launch { repo.touch(t.id) }
    }

    /** Enter нажимает сам пользователь; приложение само ничего не отправляет. */
    private fun doEnter() {
        val ic = currentInputConnection ?: return
        undo = null
        ks.suggestions = emptyList()
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun isPassword(info: EditorInfo?): Boolean {
        val t = info?.inputType ?: return false
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        return (cls == InputType.TYPE_CLASS_TEXT && (
            v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
            (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
    }
}
