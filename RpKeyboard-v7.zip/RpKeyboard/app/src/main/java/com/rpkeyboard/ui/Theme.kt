package com.rpkeyboard.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun RpTheme(dark: Boolean, content: @Composable () -> Unit) {
    val cs = if (dark) {
        darkColorScheme(
            primary = Color(0xFFDDE3FF),
            onPrimary = Color(0xFF1A1C2B),
            background = Color(0xFF181A28),
            onBackground = Color(0xFFE6E6EA),
            surface = Color(0xFF212436),
            onSurface = Color(0xFFEDEDF2),
            surfaceVariant = Color(0xFF2A2D3F),
            onSurfaceVariant = Color(0xFF9EA2B8),
            secondaryContainer = Color(0xFF373B54),
            onSecondaryContainer = Color(0xFFE6E8F8)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF3B5BDB),
            onPrimary = Color(0xFFFFFFFF),
            background = Color(0xFFD7DBE3),
            onBackground = Color(0xFF1B1B1F),
            surface = Color(0xFFF2F3F7),
            onSurface = Color(0xFF1B1B1F),
            surfaceVariant = Color(0xFFFFFFFF),
            onSurfaceVariant = Color(0xFF5A5D68),
            secondaryContainer = Color(0xFFB9C0D0),
            onSecondaryContainer = Color(0xFF1B1B1F)
        )
    }
    MaterialTheme(colorScheme = cs, content = content)
}
