package com.rpkeyboard.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(
    tableName = "folders",
    foreignKeys = [ForeignKey(
        entity = FolderEntity::class,
        parentColumns = ["id"],
        childColumns = ["parentId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("parentId")]
)
data class FolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val parentId: Long? = null,
    val name: String,
    val position: Int = 0
)

@Entity(
    tableName = "templates",
    foreignKeys = [ForeignKey(
        entity = FolderEntity::class,
        parentColumns = ["id"],
        childColumns = ["folderId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("folderId")]
)
data class TemplateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val folderId: Long? = null,
    val name: String,
    val text: String,
    val mode: String = "chat",
    val position: Int = 0,
    val favorite: Boolean = false,
    val lastUsed: Long = 0
)

@Dao
interface RpDao {
    @Query("SELECT * FROM folders ORDER BY position, id")
    fun allFolders(): Flow<List<FolderEntity>>

    @Query("SELECT * FROM folders ORDER BY position, id")
    suspend fun allFoldersOnce(): List<FolderEntity>

    @Query("SELECT * FROM folders WHERE parentId IS :p ORDER BY position, id")
    suspend fun foldersOnce(p: Long?): List<FolderEntity>

    @Query("SELECT COALESCE(MAX(position), -1) + 1 FROM folders WHERE parentId IS :p")
    suspend fun nextFolderPos(p: Long?): Int

    @Query("SELECT COUNT(*) FROM folders")
    suspend fun folderCount(): Int

    @Insert
    suspend fun insertFolder(f: FolderEntity): Long

    @Update
    suspend fun updateFolder(f: FolderEntity)

    @Delete
    suspend fun deleteFolder(f: FolderEntity)

    @Query("SELECT * FROM templates ORDER BY position, id")
    fun allTemplates(): Flow<List<TemplateEntity>>

    @Query("SELECT * FROM templates ORDER BY position, id")
    suspend fun allTemplatesOnce(): List<TemplateEntity>

    @Query("SELECT * FROM templates WHERE folderId IS :f ORDER BY position, id")
    suspend fun templatesOnce(f: Long?): List<TemplateEntity>

    @Query("SELECT COALESCE(MAX(position), -1) + 1 FROM templates WHERE folderId IS :f")
    suspend fun nextTemplatePos(f: Long?): Int

    @Query("SELECT * FROM templates WHERE lastUsed > 0 ORDER BY lastUsed DESC LIMIT 20")
    fun recents(): Flow<List<TemplateEntity>>

    @Insert
    suspend fun insertTemplate(t: TemplateEntity): Long

    @Update
    suspend fun updateTemplate(t: TemplateEntity)

    @Delete
    suspend fun deleteTemplate(t: TemplateEntity)

    @Query("UPDATE templates SET lastUsed = :time WHERE id = :id")
    suspend fun setLastUsed(id: Long, time: Long)

    @Query("UPDATE templates SET lastUsed = 0")
    suspend fun clearRecents()

    @Query("UPDATE templates SET favorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: Long, fav: Boolean)

    @Query("DELETE FROM templates")
    suspend fun clearTemplates()

    @Query("DELETE FROM folders")
    suspend fun clearFolders()
}

@Database(entities = [FolderEntity::class, TemplateEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): RpDao
}
